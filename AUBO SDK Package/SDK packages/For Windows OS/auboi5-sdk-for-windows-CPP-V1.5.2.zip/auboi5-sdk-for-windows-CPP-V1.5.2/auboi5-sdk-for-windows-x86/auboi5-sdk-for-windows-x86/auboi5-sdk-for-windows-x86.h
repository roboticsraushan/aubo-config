#pragma once

#include <string>
#include "resource.h"