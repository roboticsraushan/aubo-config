# aubo-sdk-example
aubo robot c++ sdk example

## build step
  1. cd src
  2. mkdir build
  3. cd build
  4. cmake ..
  5. make