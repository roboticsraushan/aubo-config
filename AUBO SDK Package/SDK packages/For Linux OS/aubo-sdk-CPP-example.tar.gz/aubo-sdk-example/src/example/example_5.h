#ifndef EXAMPLE_5_H
#define EXAMPLE_5_H

#include "AuboRobotMetaType.h"
#include "serviceinterface.h"

class Example_5
{
public:
    /**
     * @brief demo
     *
     * Trajectory movement
     *
     */
    static void demo();

    static void demo1();
};

#endif // EXAMPLE_5_H
