#ifndef EXAMPLE_8_H
#define EXAMPLE_8_H

class Example_8
{
public:
    /**
     * @brief demo
     *
     * Positive and negative solution interface
     */
    static void demo();

    static void FK();

    static void IK();
};

#endif // EXAMPLE_8_H
